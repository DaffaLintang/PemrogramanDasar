/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acara5all;

/**
 *
 * @author daffa
 */
public class Output_println_print {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("1. println");
        System.out.println("2. println");
        System.out.print("1. print");
        System.out.print("2. print");
    }
    
}
