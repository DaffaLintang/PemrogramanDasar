package acara5all;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import java.util.Scanner;
/**
 *
 * @author daffa
 */
public class Acara56 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
           Scanner input = new Scanner(System.in);
           System.out.print("Masukkan nama depan: ");
           String namaDepan = input.next();
                
           System.out.print("Masukkan nama belakang: ");
           String namaBelakang = input.next();
           
           System.out.println("Hallo");
           System.out.println( namaDepan + " "+ namaBelakang); 
           
    }
 
  
}
