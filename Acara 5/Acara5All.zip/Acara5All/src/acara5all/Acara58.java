/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acara5all;

/**
 *
 * @author daffa
 */
public class Acara58 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Twinkle, twinkle, little star,"
                           + "\n\tHow I wonder what you are!"
                           + "\n\t\tUp above the world so high,"
                           + "\n\t\tLike a diamond in the sky,"
                           + "\nTwinkle, twinkle, little star,"
                           + "\n\tHow I wonder what you are");
    }
    
}
